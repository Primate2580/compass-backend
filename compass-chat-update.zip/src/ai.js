// Talks to the Claude API. We use plain fetch, so there's nothing extra to install.
import "dotenv/config";

const API_URL = "https://api.anthropic.com/v1/messages";

export async function callClaude({ system, messages, tools }) {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error("ANTHROPIC_API_KEY is missing. Add it to your .env file.");
  }

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 1500, // caps the length (and cost) of each reply
      system,
      messages,
      tools,
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    const err = new Error(`Anthropic API error ${res.status}: ${body}`);
    err.isAiError = true; // lets the server return a friendly 502 instead of leaking details
    throw err;
  }
  return res.json();
}
