# Compass backend (starter)

Express API that saves onboarding data to your Neon database and builds each user's system prompt.

## Setup

1. Make sure you already ran `compass_schema.sql` in Neon's SQL Editor.
2. In this folder:
   ```bash
   npm install
   cp .env.example .env      # then paste your Neon connection string into .env
   npm run test-db           # should print "Connected to Neon. Server time: ..."
   npm run dev               # starts the API on http://localhost:3000
   ```

## Try it (in a second terminal)

Create a user and copy the `id` from the response:

```bash
curl -X POST http://localhost:3000/users \
  -H "Content-Type: application/json" \
  -d '{"email":"ada@test.com","full_name":"Ada","timezone":"Africa/Lagos"}'
```

Save some profile answers (replace USER_ID):

```bash
curl -X PUT http://localhost:3000/users/USER_ID/profile \
  -H "Content-Type: application/json" \
  -d '{"role_type":"freelancer","role_title":"graphic designer","industry":"design","peak_energy":"early_morning","planning_style":"flexible","deadline_behavior":"last_minute","leisure_min_hours_week":8}'
```

Add a pain point and a fixed commitment:

```bash
curl -X POST http://localhost:3000/users/USER_ID/answers \
  -H "Content-Type: application/json" \
  -d '{"question_key":"pain_points","answer":"clients pay late and I overbook myself"}'

curl -X POST http://localhost:3000/users/USER_ID/commitments \
  -H "Content-Type: application/json" \
  -d '{"title":"Church","days":[0],"start_time":"09:00","end_time":"12:00"}'
```

See the finished system prompt:

```bash
curl http://localhost:3000/users/USER_ID/system-prompt
```

Prefer a point-and-click tool? Use Thunder Client (VS Code extension) or Postman with the same URLs and JSON bodies.

## Valid values

- `role_type`: employee, freelancer, business_owner, student, between_jobs
- `income_pattern`: steady, irregular, just_starting
- `peak_energy`: early_morning, midday, afternoon, night
- `planning_style`: structured, flexible
- `deadline_behavior`: starts_early, plans_then_starts, last_minute

## Chat with Compass

Add `ANTHROPIC_API_KEY` to your `.env` (create a key at console.anthropic.com; API usage is billed separately from a claude.ai subscription, so check the pricing page and set a spending limit while testing). Restart `npm run dev`, then:

```bash
curl -X POST http://localhost:3000/users/USER_ID/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"I have 5 things on my plate: invoice two clients, redo my portfolio, reply to emails, watch a webinar, plan my sister'"'"'s birthday. Sort them for me."}'
```

The response contains `reply`, a `conversation_id`, and `actions` (anything Claude saved). Send the same `conversation_id` back to continue the conversation:

```bash
curl -X POST http://localhost:3000/users/USER_ID/chat \
  -H "Content-Type: application/json" \
  -d '{"conversation_id":"CONVERSATION_ID","message":"Yes, save those tasks."}'
```

Then check what was saved:

```bash
curl http://localhost:3000/users/USER_ID/tasks
curl http://localhost:3000/users/USER_ID/conversations/CONVERSATION_ID/messages
```

How a chat turn works: the server builds the system prompt from the user's profile, loads the last 20 messages, and calls Claude. If Claude asks to use a tool (`list_open_tasks`, `add_task`, `create_goal`), the server runs it against Neon and sends the result back, repeating until Claude gives a final answer. Then both messages are saved.

## What's not here yet

- **Login.** Right now anyone who knows a user id can read that user's data. That's fine on your own computer, but add authentication (for example Neon Auth, Supabase Auth, or JWT) before putting this online.
- **Per-user limits.** Add a daily message cap per user before launch so one person can't run up your API bill.
- **Scheduling, insights and weekly review tools.** The next tools to add (`schedule_blocks`, `insights`, `weekly_reviews`).
