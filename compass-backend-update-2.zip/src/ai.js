// Talks to the Claude API. We use plain fetch, so there's nothing extra to install.
import "dotenv/config";

const API_URL = "https://api.anthropic.com/v1/messages";

export async function callClaude({ system, messages, tools }) {
  if (!process.env.ANTHROPIC_API_KEY) {
    const err = new Error("The AI key isn't set up on the server yet. Add ANTHROPIC_API_KEY to the backend .env file and restart it.");
    err.httpStatus = 503; // the error handler sends this message to the app as-is
    throw err;
  }

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 1500, // caps the length (and cost) of each reply
      system,
      messages,
      tools,
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    const err = new Error(`Anthropic API error ${res.status}: ${body}`);
    err.isAiError = true; // lets the server return a friendly 502 instead of leaking details
    throw err;
  }
  return res.json();
}
