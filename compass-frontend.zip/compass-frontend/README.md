# Compass frontend

React (Vite) app with a welcome screen, a step-by-step onboarding flow, and a chat screen with a live task list.

## Run it

1. Make sure the backend is running (`npm run dev` inside `compass-backend`) and you've applied the backend update that came with this.
2. In this folder:
   ```bash
   npm install
   npm run dev
   ```
3. Open http://localhost:5173

If your backend isn't on port 3000, copy `.env.example` to `.env` and change `VITE_API_URL`.

## How it works

- **Welcome:** creates a user (`POST /users`). The browser remembers the user id in `localStorage` (no login yet).
- **Onboarding:** one question per screen. Edit the `STEPS` list at the top of `src/components/Onboarding.jsx` to add or change questions. Answers are saved to the profile, goals, overheads and commitments tables when the last question is done.
- **Chat:** sends messages to `POST /users/:id/chat`. Replies are shown as formatted text (tables included). When Compass saves a task or goal, a green badge appears and the task panel refreshes.
- **Tasks:** grouped by Eisenhower quadrant. Tick a box to mark a task done.

## Files

```
src/api.js                     all backend calls
src/App.jsx                    decides which screen to show
src/components/Welcome.jsx     sign-up screen
src/components/Onboarding.jsx  question flow + saving
src/components/Workspace.jsx   chat + task panel
src/styles.css                 all styling (light and dark mode)
```

## Testing as a new person

Click **Start over** in the top bar (or clear this site's localStorage), then use a different email.
